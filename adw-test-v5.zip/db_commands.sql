CREATE USER ocitest Identified by R3m3mb3rThis;
Grant Create session, resource to ocitest;
Alter user ocitest Quota unlimited on DATA;

  CREATE TABLE "OCITEST"."WINEREVIEWS130K" 
   (	"COUNTRY" VARCHAR2(50), 
	"DESIGNATION" VARCHAR2(150), 
	"ID" NUMBER(38,0), 
	"POINTS" NUMBER(38,0), 
	"POINTS_BIN" VARCHAR2(40), 
	"PRICE" NUMBER(38,0), 
	"PROVINCE" VARCHAR2(50), 
	"REGION_1" VARCHAR2(150), 
	"REGION_2" VARCHAR2(50), 
	"TITLE" VARCHAR2(200), 
	"VARIETY" VARCHAR2(75), 
	"WINERY" VARCHAR2(200)
   )  
  TABLESPACE "DATA" ;
  
 BEGIN	
	DBMS_CLOUD.CREATE_CREDENTIAL (
		credential_name =>  '&1',
		username => '&2',
		password => '&3' );
	END;
/

BEGIN 
	DBMS_CLOUD.COPY_DATA(
		table_name => 'WINEREVIEWS130K',
		schema_name => 'OCITEST',
        credential_name => '&1',
        file_uri_list => '&4',
		format => json_object('type' value 'CSV', 'skipheaders' value '1',	'rejectlimit' value '10000'));
	END;
/

        		