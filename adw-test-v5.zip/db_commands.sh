#!/bin/bash
echo `pwd`
echo $SQL_PATH
echo $CRED_NAME $TENANCY_USER $AUTH_TOKEN $FILE_URI
$SQLCL_PATH/sql -oci /nolog <<EOF
 set cloudconfig ./Wallet_ORCLJ.zip
connect admin/R3m3mb3rThis@ORCLJ_HIGH
START db_commands.sql $CRED_NAME $TENANCY_USER $AUTH_TOKEN $FILE_URI
select count(*) from ocitest.winereviews130k;
EOF
