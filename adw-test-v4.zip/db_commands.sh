#!/bin/bash
echo `pwd`
echo $SQL_PATH
echo $CRED_NAME $TENANCY_USER $AUTH_TOKEN $FILE_URI
$SQLCL_PATH/sql.exe -oci /nolog <<EOF
 set cloudconfig G:/MyData/2020-projects/ZipLabs-OOW/adw-test/Wallet_ORCLJ.zip
connect admin/R3m3mb3rThis@ORCLJ_HIGH
START db_commands.sql $CRED_NAME $TENANCY_USER $AUTH_TOKEN $FILE_URI
EOF
